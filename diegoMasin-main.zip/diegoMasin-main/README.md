### Hi, you can just call me Diego <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="25px">
<a href="https://www.linkedin.com/in/diego-masin-dev/">
  <img align="left" alt="Diego LinkedIN" width="22px" src="https://raw.githubusercontent.com/peterthehan/peterthehan/master/assets/linkedin.svg" />
</a>

![](https://visitor-badge.glitch.me/badge?page_id=diegoMasin.diegoMasin)

I am a passionate and self-taught Full Stack Web and Mobile Developer <img src="https://media.giphy.com/media/WUlplcMpOCEmTGBtBW/giphy.gif" width="30">

  <img align="right" alt="GIF" src="https://github.com/abhisheknaiidu/abhisheknaiidu/blob/master/code.gif?raw=true" width="500" height="320" />
  
**A little more about me...**

- 👨🏽‍💻 At the moment I am studying Typecript and React a lot;
- 🌱 I love learning new things; 
- 💬 I'm always happy when I work with projects that have a lot of financial calculations...;
- 📫 
I really enjoy studying in groups and teaching those who need help;
- 📝 [My Resume](https://drive.google.com/file/d/1LZG74BtwI14RuRmhd9h9lYGU2y6RSr74/view)

**Languages and Tools:**  

<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/javascript/javascript.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/typescript/typescript.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/react/react.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/nodejs/nodejs.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/python/python.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/django/django.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/html/html.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/css/css.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/postgresql/postgresql.png"></code>
<code><img height="20" src="https://raw.githubusercontent.com/github/explore/80688e429a7d4ef2fca1e82350fe8e3517d3494d/topics/git/git.png"></code>

📊 **This last week I spent my Time On:**
<!--START_SECTION:waka-->
```text
React      12 hrs 38 mins  █████████████████████▒░░░   85.87 % 
Node       1 hr 34 mins    ██▓░░░░░░░░░░░░░░░░░░░░░░   10.73 % 
Html/Css   20 mins         ▓░░░░░░░░░░░░░░░░░░░░░░░░   02.31 % 
```
<!--END_SECTION:waka-->
