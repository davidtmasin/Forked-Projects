export class RouteExistsError extends Error {}
