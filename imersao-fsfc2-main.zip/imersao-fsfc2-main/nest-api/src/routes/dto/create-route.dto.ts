export class CreateRouteDto {}
