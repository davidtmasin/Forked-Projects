### What's up, dude! 🖖

I'm David Teixeira from Brazil (🇧🇷) and I decided to head into in this Development's World, after all, code creation is the POWER✨! I'm studying some projects proposed by RocketSeat and Alura, and some their already available are in my [repositories](https://github.com/DavidTeixeira92?tab=repositories).

Nowadays, I'm a informatic professional, especifically, in the support's area, but too I'm a teacher in the platform online, Youtube, [TD Educação channel](https://juntossomosmais.com.br). It's my hobby.

In my free time I like to play mobile games, to watch Netflix and YouTube and to learn something new.

Finally, I leave the following message:

CODE IS LOVE! ❤️

CODE IS LIFE! ❤️

Would you like to find me?

[![Youtube Badge](https://img.shields.io/badge/-Youtube-FF0000?style=flat-square&labelColor=FF0000&logo=youtube&logoColor=white&link=https://youtube.com/c/TioDavidEducação)](https://youtube.com/c/TioDavidEducação)
[![Linkedin Badge](https://img.shields.io/badge/-LinkedIn-blue?style=flat-square&logo=Linkedin&logoColor=white&link=www.linkedin.com/in/davidteixeirademasin)](www.linkedin.com/in/davidteixeirademasin)





<!--
**DavidTeixeira92/DavidTeixeira92** is a ✨ _special_ ✨ repository because its `README.md` (this file) appears on your GitHub profile.

Here are some ideas to get you started:

- 🔭 I’m currently working on ...
- 🌱 I’m currently learning ...
- 👯 I’m looking to collaborate on ...
- 🤔 I’m looking for help with ...
- 💬 Ask me about ...
- 📫 How to reach me: ...
- 😄 Pronouns: ...
- ⚡ Fun fact: ...
-->
