# Hello There :metal:

<h1 align="center"> 
  Thiago Lanza | Back-end Developer
</h1>

<p align="center">  
  <img src="https://img.shields.io/badge/-Javascript-yellow" alt="Javascript">
  <img src="https://img.shields.io/badge/-NodeJS-brightgreen" alt"Node.JS">   
  <img src="https://img.shields.io/badge/-PHP-blue" alt"PHP">
  <img src="https://img.shields.io/badge/-Laravel-orange" alt"Laravel"> 
</p>

## Welcome to my Github :)
:octocat: Here I'll share my code and do my best to contribute to coders community.

:computer: I'm a Jr Developer working with back-end.

:metal:&nbsp; I'm constantly looking for best ways to improve my skills on the best of technology!

:briefcase: Working as PHP/Laravel Developer. :]


```js
// Life's motivation
if(sad) {
  getCoffee();
  beAwesome();
  sad = false;
}

keepCoding();
```
