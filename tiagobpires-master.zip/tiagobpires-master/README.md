# Tiago Barros Pires
[![LinkedIn Badge](https://img.shields.io/badge/tiagobpires-blue?style=flat&logo=linkedin&labelColor=blue&link=https://www.linkedin.com/in/tiagobpires/)](https://www.linkedin.com/in/tiagobpires/)
[![Gmail Badge](https://img.shields.io/badge/tiagobarrospires%40gmail.com-c14438?style=flat&logo=gmail&logoColor=white&link=mailto:tiagobarrospires@gmail.com)](mailto:tiagobarrospires@gmail.com)
<img align="right" alt="GIF" src="https://media.giphy.com/media/WTplYWk2SRyrJGMSxo/source.gif" width="350" height="270"/>

## Hello World <img src="https://media.giphy.com/media/hvRJCLFzcasrR4ia7z/giphy.gif" width="25px">

🎓 &nbsp; Graduating in Computer Science at UECE
<br/>:man_technologist: &nbsp; I solve problems using programming
<br/>:sunglasses: &nbsp; I love technologies, games and series
<br/>:dart: &nbsp; Don't wait for the right time, start now
<br/>🇧🇷 &nbsp; I'm from Brazil
